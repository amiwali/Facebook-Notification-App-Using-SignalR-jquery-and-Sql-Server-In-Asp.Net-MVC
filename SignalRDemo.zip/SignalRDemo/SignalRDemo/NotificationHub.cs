﻿using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SignalRDemo
{
    public class NotificationHub : Hub
    {
        //Nothing required here 
        //public void Hello()
        //{
        //    Clients.All.hello();
        //}
    }
}